<?php

return array(
    'author' => 'Max Lazar',
    'author_url' => 'https://eec.ms/',
    'name' => 'MX QR CODE',
    'description' => 'MX QR Code Generator for ExpressionEngine',
    'version' => '4.0.5',
    'namespace' => 'Mx\Qr_code',
    'settings_exist' => false,
    'plugin.typography' => true,
);
